package com.occamedu.bean;

/**
 * @author ysw
 * @email 1461182123@qq.com
 * @date 2020/10/17 4:14 下午
 * @description
 */
public class User {
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
